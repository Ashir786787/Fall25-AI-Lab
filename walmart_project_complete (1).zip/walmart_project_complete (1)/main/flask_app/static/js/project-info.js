document.addEventListener('DOMContentLoaded', function() {
    getInfo();
});

function getInfo() {
    fetch('/api/project-info')
        .then(res => res.json())
        .then(data => {
            showOverview(data);
            if (data.data_stats) showStats(data.data_stats);
            if (data.performance) showPerf(data.performance);
            if (data.features) showFeat(data.features);
            if (data.models) showMod(data.models);
        });
}

function showOverview(data) {
    var t = document.getElementById('projectTitle');
    var d = document.getElementById('projectDesc');
    if (t) t.textContent = data.title;
    if (d) d.textContent = data.description;
}

function showStats(s) {
    var div = document.getElementById('datasetInfo');
    if (!div) return;
    
    div.innerHTML = "<table class='table'>" +
        "<tr><td>Stores</td><td>" + s.stores + "</td></tr>" +
        "<tr><td>Depts</td><td>" + s.departments + "</td></tr>" +
        "<tr><td>Records</td><td>" + s.records + "</td></tr>" +
        "<tr><td>Range</td><td>" + s.date_range + "</td></tr>" +
        "</table>";
}

function showPerf(p) {
    var div = document.getElementById('performanceInfo');
    if (!div) return;
    
    div.innerHTML = "<table class='table'>" +
        "<tr><td>RMSE</td><td>" + p.RMSE + "</td></tr>" +
        "<tr><td>MAE</td><td>" + p.MAE + "</td></tr>" +
        "<tr><td>R2</td><td>" + p['R Score'] + "</td></tr>" +
        "</table>";
}

function showFeat(f) {
    var div = document.getElementById('featuresContainer');
    if (!div) return;
    div.innerHTML = '';

    f.forEach(item => {
        var c = document.createElement('div');
        c.className = 'col-md-6 mb-2';
        c.innerHTML = "<div class='card p-2'>" + item + "</div>";
        div.appendChild(c);
    });
}

function showMod(m) {
    var div = document.getElementById('modelsContainer');
    if (!div) return;
    div.innerHTML = '';

    m.forEach(item => {
        var c = document.createElement('div');
        c.className = 'col-md-4 mb-2';
        c.innerHTML = "<div class='card p-3 text-center'>" + item + "</div>";
        div.appendChild(c);
    });
}
