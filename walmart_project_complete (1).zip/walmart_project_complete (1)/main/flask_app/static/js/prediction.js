document.addEventListener('DOMContentLoaded', function() {
    var form = document.getElementById('predictionForm');
    var s_select = document.getElementById('storeSelect');
    
    if (form) {
        form.addEventListener('submit', doPredict);
    }
    
    if (s_select) {
        s_select.addEventListener('change', function() {
            var sid = this.value;
            if (sid) {
                getDepts(sid);
            }
        });
    }
});

function getDepts(sid) {
    var d_select = document.getElementById('deptSelect');
    if (!d_select) return;
    
    d_select.disabled = true;
    d_select.innerHTML = '<option value="">Loading...</option>';
    
    fetch('/api/combinations/' + sid)
        .then(res => res.json())
        .then(data => {
            d_select.innerHTML = '<option value="">Choose a department...</option>';
            data.departments.forEach(d => {
                var opt = document.createElement('option');
                opt.value = d;
                opt.textContent = "Dept " + d;
                d_select.appendChild(opt);
            });
            d_select.disabled = false;
        });
}

function doPredict(e) {
    e.preventDefault();
    
    var s = document.getElementById('storeSelect').value;
    var d = document.getElementById('deptSelect').value;

    if (!s || !d) {
        alert('Select store and dept!');
        return;
    }

    fetch('/api/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ store: s, department: d })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            showRes(data.prediction);
        } else {
            alert(data.message);
        }
    });
}

function showRes(p) {
    var card = document.getElementById('resultCard');
    var empty = document.getElementById('noResultCard');

    if (!card || !empty) return;

    document.getElementById('predictedSales').textContent = "$" + p.predicted_sales;
    document.getElementById('confidence').textContent = p.confidence + "%";
    document.getElementById('resultStore').textContent = "Store: " + p.store;
    document.getElementById('resultDept').textContent = "Dept: " + p.department;
    document.getElementById('histAvg').textContent = "$" + p.historical_avg;

    card.style.display = 'block';
    empty.style.display = 'none';
}
