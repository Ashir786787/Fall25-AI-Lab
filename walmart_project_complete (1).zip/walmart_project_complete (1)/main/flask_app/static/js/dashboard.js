document.addEventListener('DOMContentLoaded', function() {
    loadData();
});

function loadData() {
    fetch('/api/overview')
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                showHolidayChart(data.holiday_impact);
                showMonthlyChart(data.monthly_trend);
                showStores(data.stores);
                showDepts(data.departments);
            }
        })
        .catch(err => console.log(err));
}

function showHolidayChart(h_data) {
    var ctx = document.getElementById('holidayChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Regular', 'Holiday'],
            datasets: [{
                label: 'Avg Sales',
                data: [h_data.regular, h_data.holiday],
                backgroundColor: ['#3b82f6', '#ec4899']
            }]
        },
        options: {
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
}

function showMonthlyChart(m_data) {
    var ctx = document.getElementById('monthlyChart');
    if (!ctx) return;
    
    var labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var vals = [];
    for(var i=1; i<=12; i++) {
        vals.push(m_data[i] || 0);
    }

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Monthly Avg',
                data: vals,
                borderColor: '#3b82f6',
                fill: false
            }]
        }
    });
}

function showStores(stores) {
    var div = document.getElementById('topStoresContainer');
    if (!div) return;
    div.innerHTML = '';

    for (var s_id in stores) {
        var s = stores[s_id];
        var row = document.createElement('div');
        row.style.borderBottom = "1px solid #ccc";
        row.style.padding = "5px";
        row.innerHTML = "Store " + s_id + ": $" + s.Weekly_Sales;
        div.appendChild(row);
    }
}

function showDepts(depts) {
    var div = document.getElementById('topDeptsContainer');
    if (!div) return;
    div.innerHTML = '';

    for (var d_id in depts) {
        var val = depts[d_id];
        var row = document.createElement('div');
        row.style.borderBottom = "1px solid #ccc";
        row.style.padding = "5px";
        row.innerHTML = "Dept " + d_id + ": $" + val;
        div.appendChild(row);
    }
}
