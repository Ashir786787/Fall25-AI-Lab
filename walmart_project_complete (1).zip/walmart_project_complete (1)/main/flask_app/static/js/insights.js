document.addEventListener('DOMContentLoaded', function() {
    loadData();
});

function loadData() {
    fetch('/api/insights')
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                showSum(data.summary);
                showTop(data.top_stores);
                showSea(data.seasonal_pattern);
            }
        });
}

function showSum(s) {
    var ts = document.getElementById('totalSales');
    var hi = document.getElementById('holidayImpact');
    
    if (ts) ts.textContent = "$" + (s.total_sales / 1000000).toFixed(1) + "M";
    if (hi) hi.textContent = "+" + s.holiday_impact_percent + "%";

    var card = document.querySelector('#holidayImpact');
    if (card) {
        var p = card.closest('.card').querySelector('p');
        if (p) {
            p.innerHTML = "Reg: $" + s.regular_week_avg + "<br>Hol: $" + s.holiday_week_avg;
        }
    }
}

function showTop(t_stores) {
    var ctx = document.getElementById('topStoresChart');
    if (!ctx) return;
    
    var labels = Object.keys(t_stores);
    var vals = Object.values(t_stores);

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels.map(l => "Store " + l),
            datasets: [{
                label: 'Avg Sales',
                data: vals,
                backgroundColor: '#3b82f6'
            }]
        },
        options: {
            indexAxis: 'y'
        }
    });
}

function showSea(sea) {
    var ctx = document.getElementById('seasonalChart');
    if (!ctx) return;
    
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var vals = [];
    for(var i=1; i<=12; i++) {
        vals.push(sea[i] || 0);
    }

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: months,
            datasets: [{
                label: 'Monthly Avg',
                data: vals,
                borderColor: '#ef4444',
                fill: false
            }]
        }
    });
}
