document.addEventListener('DOMContentLoaded', function() {
    loadData();
});

function loadData() {
    fetch('/api/analytics')
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                showCharts(data.sales_distribution);
                showTable(data.sales_distribution);
                showTypeChart(data.store_types);
            }
        });
}

function showCharts(s) {
    var ctx = document.getElementById('distributionChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Min', 'Median', 'Mean', 'Max'],
            datasets: [{
                label: 'Sales',
                data: [s.min, s.median, s.mean, s.max],
                backgroundColor: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444']
            }]
        }
    });
}

function showTable(s) {
    var body = document.getElementById('statsTable');
    if (!body) return;
    
    body.innerHTML = 
        "<tr><td>Count</td><td>" + s.count + "</td></tr>" +
        "<tr><td>Mean</td><td>$" + s.mean + "</td></tr>" +
        "<tr><td>Median</td><td>$" + s.median + "</td></tr>" +
        "<tr><td>Min</td><td>$" + s.min + "</td></tr>" +
        "<tr><td>Max</td><td>$" + s.max + "</td></tr>";
}

function showTypeChart(t_data) {
    var ctx = document.getElementById('storeTypeChart');
    if (!ctx) return;
    
    var labels = Object.keys(t_data);
    var vals = labels.map(l => t_data[l]);

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Avg Sales',
                data: vals,
                backgroundColor: ['#3b82f6', '#10b981', '#f59e0b']
            }]
        }
    });
}
