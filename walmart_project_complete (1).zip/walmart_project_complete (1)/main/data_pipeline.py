import os
import sys
import time
import pandas as pd
import numpy as np
import pyodbc
from datetime import datetime

D_PATH = r".\data"
S_NAME = "(localdb)\\mssqllocaldb"
DB_NAME = "WalmartSalesForecast"
B_SIZE = 2000

def get_connection():
    drvs = [
        "ODBC Driver 17 for SQL Server",
        "ODBC Driver 18 for SQL Server",
        "SQL Server",
    ]
    for d in drvs:
        try:
            c = pyodbc.connect(
                f"Driver={{{d}}};"
                f"Server={S_NAME};"
                f"Database={DB_NAME};"
                f"Trusted_Connection=yes;"
                f"TrustServerCertificate=yes;",
                timeout=15,
            )
            return c
        except:
            continue
    return None

def read_files():
    f_names = {
        "stores":   "stores.csv",
        "features": "features.csv",
        "train":    "train.csv",
        "test":     "test.csv",
    }

    res = {}
    for k, v in f_names.items():
        p = os.path.join(D_PATH, v)
        if os.path.exists(p):
            df = pd.read_csv(p, low_memory=False)
            res[k] = df
    return res

def clean_data(raw_data):
    final = {}

    if "stores" in raw_data:
        df = raw_data["stores"].copy()
        df["Store"] = pd.to_numeric(df["Store"], errors="coerce")
        df["Size"]  = pd.to_numeric(df["Size"],  errors="coerce")
        df["Type"]  = df["Type"].astype(str).str.upper()
        df = df.dropna(subset=["Store"]).drop_duplicates(subset=["Store"])
        final["stores"] = df

    if "features" in raw_data:
        df = raw_data["features"].copy()
        df["IsHoliday"] = df["IsHoliday"].astype(str).map({'True':1, 'False':0, '1':1, '0':0, '1.0':1, '0.0':0}).fillna(0).astype(int)
        df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
        df = df.dropna(subset=["Store", "Date"])
        for c in ["MarkDown1","MarkDown2","MarkDown3","MarkDown4","MarkDown5"]:
            if c in df.columns:
                df[c] = pd.to_numeric(df[c], errors="coerce")
        for c in ["Temperature","Fuel_Price","CPI","Unemployment"]:
            if c in df.columns:
                df[c] = pd.to_numeric(df[c], errors="coerce")
                df[c] = df[c].fillna(df[c].median())
        df["Store"] = df["Store"].astype(int)
        df = df.drop_duplicates(subset=["Store","Date"])
        final["features"] = df

    if "train" in raw_data:
        df = raw_data["train"].copy()
        df["IsHoliday"] = df["IsHoliday"].astype(str).map({'True':1, 'False':0, '1':1, '0':0, '1.0':1, '0.0':0}).fillna(0).astype(int)
        df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
        df["Weekly_Sales"] = pd.to_numeric(df["Weekly_Sales"], errors="coerce")
        df["Store"] = pd.to_numeric(df["Store"], errors="coerce")
        df["Dept"] = pd.to_numeric(df["Dept"],  errors="coerce")
        df = df.dropna(subset=["Store","Dept","Date","Weekly_Sales"])
        df["Store"] = df["Store"].astype(int)
        df["Dept"]  = df["Dept"].astype(int)
        final["train"] = df

    if "test" in raw_data:
        df = raw_data["test"].copy()
        df["IsHoliday"] = df["IsHoliday"].astype(str).map({'True':1, 'False':0, '1':1, '0':0, '1.0':1, '0.0':0}).fillna(0).astype(int)
        df["Date"]  = pd.to_datetime(df["Date"], errors="coerce")
        df["Store"] = pd.to_numeric(df["Store"], errors="coerce")
        df["Dept"]  = pd.to_numeric(df["Dept"],  errors="coerce")
        df = df.dropna(subset=["Store","Dept","Date"])
        df["Store"] = df["Store"].astype(int)
        df["Dept"]  = df["Dept"].astype(int)
        final["test"] = df

    return final

def save_to_db(data_dict, conn):
    cur = conn.cursor()
    cur.fast_executemany = True
    
    mapping = {
        "stores": ("Stores", ["Store","Type","Size"]),
        "features": ("Features", ["Store","Date","Temperature","Fuel_Price","MarkDown1","MarkDown2","MarkDown3","MarkDown4","MarkDown5","CPI","Unemployment","IsHoliday"]),
        "train": ("SalesTraining", ["Store","Dept","Date","Weekly_Sales","IsHoliday"]),
        "test": ("SalesTest", ["Store","Dept","Date","IsHoliday"])
    }

    for k in ["stores", "features", "train", "test"]:
        if k not in data_dict:
            continue

        tbl, cols = mapping[k]
        df = data_dict[k]
        
        try:
            cur.execute(f"DELETE FROM {tbl}")
            conn.commit()
        except:
            pass

        cols_str = ", ".join(cols)
        qs = ", ".join(["?"] * len(cols))
        sql = f"INSERT INTO {tbl} ({cols_str}) VALUES ({qs})"

        print(f"Loading {tbl}...")
        
        rows = []
        for i, row in df.iterrows():
            r_vals = []
            for col in cols:
                val = row[col]
                if pd.isna(val):
                    r_vals.append(None)
                else:
                    r_vals.append(val)
            rows.append(tuple(r_vals))
            
            if len(rows) >= B_SIZE:
                cur.executemany(sql, rows)
                conn.commit()
                rows = []
        
        if rows:
            cur.executemany(sql, rows)
            conn.commit()
            
        print(f"Finished loading {tbl}")

    cur.close()

if __name__ == "__main__":
    print("ETL started...")
    c = get_connection()
    if c:
        raw = read_files()
        clean = clean_data(raw)
        save_to_db(clean, c)
        c.close()
        print("ETL completed successfully!")
    else:
        print("Connection failed!")