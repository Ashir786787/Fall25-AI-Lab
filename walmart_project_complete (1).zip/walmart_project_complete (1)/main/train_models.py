import os
import sys
import json
import pickle
from datetime import datetime
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score
import xgboost as xgb

DIR_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODELS_DIR = os.path.join(DIR_PATH, "models")

if not os.path.exists(MODELS_DIR):
    os.makedirs(MODELS_DIR)

def load_data():
    t_path = os.path.join(DIR_PATH, 'data', 'train.csv')
    s_path = os.path.join(DIR_PATH, 'data', 'stores.csv')
    f_path = os.path.join(DIR_PATH, 'data', 'features.csv')
    
    df_train = pd.read_csv(t_path)
    df_stores = pd.read_csv(s_path)
    df_features = pd.read_csv(f_path)
    
    df_train['Date'] = pd.to_datetime(df_train['Date'])
    df_features['Date'] = pd.to_datetime(df_features['Date'])
    
    df = df_train.merge(df_features, on=['Store', 'Date'], how='left')
    df = df.merge(df_stores, on='Store', how='left')
    
    if 'IsHoliday_x' in df.columns:
        df['IsHoliday'] = df['IsHoliday_x']
        df = df.drop(['IsHoliday_x', 'IsHoliday_y'], axis=1)
    
    df['Weekly_Sales'] = pd.to_numeric(df['Weekly_Sales'], errors='coerce')
    df = df.dropna(subset=['Weekly_Sales'])
    
    return df.sort_values('Date').reset_index(drop=True)

def process_features(df):
    df['Year'] = df['Date'].dt.year
    df['Month'] = df['Date'].dt.month
    df['Week'] = df['Date'].dt.isocalendar().week
    df['DayOfWeek'] = df['Date'].dt.dayofweek
    
    df = df.sort_values(['Store', 'Dept', 'Date']).reset_index(drop=True)
    
    lags = [1, 4, 12, 26, 52]
    for l in lags:
        df['Sales_Lag_' + str(l)] = df.groupby(['Store', 'Dept'])['Weekly_Sales'].shift(l)
        
    windows = [4, 12, 26]
    for w in windows:
        df['Sales_MA_' + str(w)] = df.groupby(['Store', 'Dept'])['Weekly_Sales'].transform(lambda x: x.rolling(window=w, min_periods=1).mean())
        
    df['Sales_EMA_12'] = df.groupby(['Store', 'Dept'])['Weekly_Sales'].transform(lambda x: x.ewm(span=12, adjust=False).mean())
    
    df = df.fillna(df.mean(numeric_only=True))
    
    cols = [
        'Store', 'Dept', 'Type', 'Size',
        'Temperature', 'Fuel_Price', 'CPI', 'Unemployment', 'IsHoliday',
        'Year', 'Month', 'Week', 'DayOfWeek',
        'Sales_Lag_1', 'Sales_Lag_4', 'Sales_Lag_12', 'Sales_Lag_26', 'Sales_Lag_52',
        'Sales_MA_4', 'Sales_MA_12', 'Sales_MA_26',
        'Sales_EMA_12'
    ]
    
    X = df[cols].copy()
    y = df['Weekly_Sales'].copy()
    
    if 'Type' in X.columns:
        X['Type'] = pd.Categorical(X['Type']).codes
        
    sc = StandardScaler()
    X_sc = sc.fit_transform(X)
    X_sc = pd.DataFrame(X_sc, columns=cols)
    
    return X_sc, y, sc

def train_model(X, y, sc):
    print("Training the model now...")
    
    m = xgb.XGBRegressor(
        n_estimators=200,
        learning_rate=0.1,
        max_depth=6,
        random_state=42
    )
    m.fit(X, y)
    
    pred = m.predict(X)
    score = r2_score(y, pred)
    print("Model R2 Score is:", score)
    
    t = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    m_path = os.path.join(MODELS_DIR, "demand_model.pkl")
    s_path = os.path.join(MODELS_DIR, "model_scaler.pkl")
    meta_path = os.path.join(MODELS_DIR, "model_metadata.json")
    
    with open(m_path, 'wb') as f:
        pickle.dump(m, f)
    with open(s_path, 'wb') as f:
        pickle.dump(sc, f)
    
    meta = {
        'time': t,
        'r2': score,
        'features': list(X.columns)
    }
    
    with open(meta_path, 'w') as f:
        json.dump(meta, f, indent=2)
        
    print("Done saving model and scaler!")

if __name__ == "__main__":
    print("Starting...")
    data = load_data()
    X, y, sc = process_features(data)
    train_model(X, y, sc)
    print("All finished!")

